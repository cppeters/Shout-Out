<header>
  	<hgroup>
    	<h1>[Shout!]</h1>
    	<h2>Keep connected with your favorite Artists!</h2>
    </hgroup>
    <nav>
	  		<ul>
	    		<li><a href="index.php" class="current">Home</a></li>
	    		<li><a href="shout.php?action=list">Song List</a></li>
	    		<li><a href="shout.php?action=search">Search</a></li>
	    		<li><a href="shout.php?action=login">Login</a></li>
	  		</ul>
  	</nav>
  </header>